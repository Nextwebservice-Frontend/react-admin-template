export const LanguagePopUpOptions = [
    'English',
    'French',
    'Arabic',
    'German',
    'বাংলা'
]