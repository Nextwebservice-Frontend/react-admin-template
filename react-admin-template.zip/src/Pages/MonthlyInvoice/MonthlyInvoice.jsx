/* eslint-disable no-unused-vars */
import React from 'react'

const MonthlyInvoice = () => {
  return (
    <div className='mt-4'>
        <h3 className='text-[#212529] font-normal'>Monthly Report List</h3>
    </div>
  )
}

export default MonthlyInvoice